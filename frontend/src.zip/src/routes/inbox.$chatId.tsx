import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  Phone,
  Video,
  MoreVertical,
  Send,
  Paperclip,
  Camera,
  Mic,
  CheckCheck,
  Check,
  MapPin,
  Home,
  Calendar,
  Shield,
  Smile,
} from "lucide-react";
import { listings } from "@/lib/cameroon-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/inbox/$chatId")({
  component: ChatScreen,
});

/* ─────────────── Types ─────────────── */
type Message = {
  id: string;
  text: string;
  timestamp: string;
  sender: "me" | "them";
  status?: "sent" | "delivered" | "read";
  type?: "text" | "booking" | "location";
};

type Conversation = {
  host: {
    name: string;
    avatar: string;
    isOnline: boolean;
    lastSeen: string;
  };
  listing: {
    title: string;
    image: string;
    price: number;
  };
  messages: Message[];
};

/* ─────────────── Mock Data ─────────────── */
const mockConversations: Record<string, Conversation> = {
  "chat-1": {
    host: {
      name: "Amadou",
      avatar: listings[0]?.images?.[0] ?? "",
      isOnline: true,
      lastSeen: "online",
    },
    listing: {
      title: listings[0]?.title ?? "Kribi Beach Villa",
      image: listings[0]?.images?.[0] ?? "",
      price: listings[0]?.usd ?? 120,
    },
    messages: [
      {
        id: "m1",
        text: "Hi Amadou! I'm interested in booking your villa for next weekend. Is it available?",
        timestamp: "2026-08-09T10:30:00Z",
        sender: "me",
        status: "read",
      },
      {
        id: "m2",
        text: "Hello! Yes, the villa is available. It's a beautiful space with ocean views and private beach access.",
        timestamp: "2026-08-09T10:32:00Z",
        sender: "them",
      },
      {
        id: "m3",
        text: "That sounds perfect. How is the wifi? I need to work remotely during my stay.",
        timestamp: "2026-08-09T10:33:00Z",
        sender: "me",
        status: "read",
      },
      {
        id: "m4",
        text: "Yes, the wifi is very fast and reliable throughout the villa! We have fiber optic with 100Mbps.",
        timestamp: "2026-08-09T10:35:00Z",
        sender: "them",
      },
      {
        id: "m5",
        text: "Great! I'll book it now. See you soon!",
        timestamp: "2026-08-09T10:36:00Z",
        sender: "me",
        status: "read",
      },
      {
        id: "m6",
        text: "Looking forward to hosting you! Let me know if you need anything else.",
        timestamp: "2026-08-09T10:38:00Z",
        sender: "them",
      },
      {
        id: "m7",
        text: "Actually, one more question — is there secure parking available for two cars?",
        timestamp: "2026-08-10T08:15:00Z",
        sender: "me",
        status: "delivered",
      },
    ],
  },
  "chat-2": {
    host: {
      name: "Marie",
      avatar: listings[1]?.images?.[0] ?? "",
      isOnline: false,
      lastSeen: "2h ago",
    },
    listing: {
      title: listings[1]?.title ?? "Mount Cameroon Lodge",
      image: listings[1]?.images?.[0] ?? "",
      price: listings[1]?.usd ?? 85,
    },
    messages: [
      {
        id: "m1",
        text: "Hi Marie, just confirming our check-in for tomorrow at 3pm.",
        timestamp: "2026-08-10T14:00:00Z",
        sender: "me",
        status: "read",
      },
      {
        id: "m2",
        text: "Looking forward to hosting you next week. The place will be ready by 2pm, so feel free to arrive early!",
        timestamp: "2026-08-10T16:30:00Z",
        sender: "them",
      },
    ],
  },
  "chat-3": {
    host: {
      name: "Jean-Pierre",
      avatar: listings[2]?.images?.[0] ?? "",
      isOnline: true,
      lastSeen: "online",
    },
    listing: {
      title: listings[2]?.title ?? "Waza Savanna Camp",
      image: listings[2]?.images?.[0] ?? "",
      price: listings[2]?.usd ?? 95,
    },
    messages: [
      {
        id: "m1",
        text: "Here are the check-in instructions. The key is under the mat by the front door.",
        timestamp: "2026-08-08T09:00:00Z",
        sender: "them",
      },
      {
        id: "m2",
        text: "The wifi password is 'Welcome2026'. Let me know if you have any issues connecting!",
        timestamp: "2026-08-08T09:01:00Z",
        sender: "them",
      },
    ],
  },
};

/* ─────────────── Utilities ─────────────── */
function formatMessageTime(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

function formatDateSeparator(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  const days = Math.floor(diff / 86400000);

  if (days === 0) return "Today";
  if (days === 1) return "Yesterday";
  return d.toLocaleDateString(undefined, {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
}

function shouldShowDateSeparator(curr: string, prev: string | null): boolean {
  if (!prev) return true;
  const c = new Date(curr).setHours(0, 0, 0, 0);
  const p = new Date(prev).setHours(0, 0, 0, 0);
  return c !== p;
}

function getInitials(name: string) {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

/* ─────────────── Avatar ─────────────── */
function ChatAvatar({
  src,
  name,
  size = 40,
}: {
  src: string;
  name: string;
  size?: number;
}) {
  const [error, setError] = useState(false);
  const initials = getInitials(name);
  const bgColor =
    initials.charCodeAt(0) % 2 === 0
      ? "bg-rose-100 text-rose-700"
      : "bg-blue-100 text-blue-700";

  return (
    <div
      className={cn(
        "rounded-full overflow-hidden border border-border/60 flex items-center justify-center text-xs font-bold shrink-0",
        (!src || error) && bgColor
      )}
      style={{ width: size, height: size }}
    >
      {!src || error ? (
        <span>{initials}</span>
      ) : (
        <img
          src={src}
          alt={name}
          className="w-full h-full object-cover"
          onError={() => setError(true)}
        />
      )}
    </div>
  );
}

/* ─────────────── Typing Indicator ─────────────── */
function TypingIndicator() {
  return (
    <div className="flex items-center gap-[3px] px-1">
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="w-[6px] h-[6px] rounded-full bg-muted-foreground/40"
          animate={{ y: [0, -5, 0] }}
          transition={{
            duration: 0.7,
            repeat: Infinity,
            delay: i * 0.12,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}

/* ─────────────── Message Bubble ─────────────── */
function MessageBubble({
  msg,
  prevMsg,
  hostAvatar,
  hostName,
}: {
  msg: Message;
  prevMsg: Message | null;
  hostAvatar: string;
  hostName: string;
}) {
  const isMe = msg.sender === "me";
  const showAvatar =
    !isMe &&
    (prevMsg?.sender !== "them" ||
      shouldShowDateSeparator(msg.timestamp, prevMsg?.timestamp));

  return (
    <motion.div
      initial={{ opacity: 0, y: 6, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className={cn(
        "flex gap-2 max-w-[88%] sm:max-w-[72%]",
        isMe ? "ml-auto flex-row-reverse" : "mr-auto"
      )}
    >
      {!isMe && showAvatar && <ChatAvatar src={hostAvatar} name={hostName} size={28} />}
      {!isMe && !showAvatar && <div className="w-[28px] shrink-0" />}

      <div className={cn("flex flex-col", isMe ? "items-end" : "items-start")}>
        <div
          className={cn(
            "relative px-[14px] py-[10px] text-[15px] leading-[1.45] shadow-sm",
            isMe
              ? "bg-foreground text-background rounded-[18px] rounded-tr-[4px]"
              : "bg-muted text-foreground rounded-[18px] rounded-tl-[4px]"
          )}
        >
          {msg.type === "booking" ? (
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 opacity-80">
                <Calendar className="w-3.5 h-3.5" />
                <span className="text-xs font-semibold uppercase tracking-wider">
                  Booking Request
                </span>
              </div>
              <p>{msg.text}</p>
            </div>
          ) : msg.type === "location" ? (
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 opacity-80">
                <MapPin className="w-3.5 h-3.5" />
                <span className="text-xs font-semibold uppercase tracking-wider">
                  Location
                </span>
              </div>
              <p>{msg.text}</p>
            </div>
          ) : (
            <p className="whitespace-pre-wrap">{msg.text}</p>
          )}

          {isMe && (
            <span className="inline-flex items-center gap-1 ml-2 text-[10px] opacity-50 mt-1 float-right">
              {formatMessageTime(msg.timestamp)}
              {msg.status === "read" && <CheckCheck className="w-3 h-3" />}
              {msg.status === "delivered" && (
                <CheckCheck className="w-3 h-3 opacity-60" />
              )}
              {msg.status === "sent" && <Check className="w-3 h-3 opacity-60" />}
            </span>
          )}
        </div>

        {!isMe && (
          <span className="text-[11px] text-muted-foreground mt-1 ml-1">
            {formatMessageTime(msg.timestamp)}
          </span>
        )}
      </div>
    </motion.div>
  );
}

/* ─────────────── Date Separator ─────────────── */
function DateSeparator({ date }: { date: string }) {
  return (
    <div className="flex items-center justify-center py-5">
      <div className="bg-muted/70 backdrop-blur-sm px-4 py-1 rounded-full">
        <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
          {formatDateSeparator(date)}
        </span>
      </div>
    </div>
  );
}

/* ─────────────── Listing Context Card ─────────────── */
function ListingContext({
  listing,
}: {
  listing: Conversation["listing"];
}) {
  return (
    <div className="mx-auto max-w-lg mb-5">
      <div className="p-3 rounded-2xl border border-border/80 bg-background/90 backdrop-blur-sm shadow-sm flex items-center gap-3">
        <div className="w-14 h-14 rounded-xl overflow-hidden shrink-0 bg-muted">
          <img
            src={listing.image}
            alt={listing.title}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = "none";
            }}
          />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[11px] text-muted-foreground font-medium mb-0.5 flex items-center gap-1">
            <Home className="w-3 h-3" /> About this stay
          </p>
          <p className="text-sm font-semibold truncate">{listing.title}</p>
          <p className="text-sm font-bold mt-0.5">
            ${listing.price}{" "}
            <span className="font-normal text-muted-foreground">night</span>
          </p>
        </div>
        <button className="shrink-0 p-2 hover:bg-muted rounded-full transition-colors">
          <ArrowLeft className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
}

/* ─────────────── Main Chat Screen ─────────────── */
function ChatScreen() {
  const { chatId } = useParams({ from: "/inbox/$chatId" });
  const conversation = mockConversations[chatId] ?? mockConversations["chat-1"];
  const [messages, setMessages] = useState<Message[]>(conversation.messages);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: "smooth",
      });
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping, scrollToBottom]);

  const handleSend = () => {
    if (!inputText.trim()) return;

    const newMsg: Message = {
      id: `m-${Date.now()}`,
      text: inputText.trim(),
      timestamp: new Date().toISOString(),
      sender: "me",
      status: "sent",
      type: "text",
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputText("");
    setIsTyping(true);

    // Auto-resize textarea
    if (inputRef.current) inputRef.current.style.height = "auto";

    // Simulate host reply
    setTimeout(() => {
      setIsTyping(false);
      setMessages((prev) => [
        ...prev,
        {
          id: `m-${Date.now() + 1}`,
          text: "Thanks for your message! I'll get back to you shortly.",
          timestamp: new Date().toISOString(),
          sender: "them",
          type: "text",
        },
      ]);
    }, 2200);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInput = (e: React.FormEvent<HTMLTextAreaElement>) => {
    const target = e.currentTarget;
    target.style.height = "auto";
    target.style.height = `${Math.min(target.scrollHeight, 128)}px`;
  };

  return (
    <div className="h-[100dvh] flex flex-col bg-background">
      {/* Header */}
      <div className="shrink-0 z-30 bg-background/95 backdrop-blur-md border-b border-border">
        <div className="flex items-center gap-2 px-3 py-2.5 max-w-3xl mx-auto">
          <Link
            to="/inbox"
            className="w-10 h-10 rounded-full hover:bg-muted flex items-center justify-center transition-colors shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>

          <div className="relative shrink-0">
            <ChatAvatar
              src={conversation.host.avatar}
              name={conversation.host.name}
              size={40}
            />
            {conversation.host.isOnline && (
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-[2.5px] border-background rounded-full" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <h2 className="font-bold text-[15px] leading-tight truncate">
              {conversation.host.name}
            </h2>
            <p className="text-xs text-muted-foreground">
              {conversation.host.isOnline
                ? "Active now"
                : `Last seen ${conversation.host.lastSeen}`}
            </p>
          </div>

          <div className="flex items-center gap-0.5">
            <button className="w-10 h-10 rounded-full hover:bg-muted flex items-center justify-center transition-colors">
              <Phone className="w-5 h-5" />
            </button>
            <button className="w-10 h-10 rounded-full hover:bg-muted flex items-center justify-center transition-colors">
              <Video className="w-5 h-5" />
            </button>
            <button className="w-10 h-10 rounded-full hover:bg-muted flex items-center justify-center transition-colors">
              <MoreVertical className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto scrollbar-thin px-4 py-4"
      >
        <div className="max-w-3xl mx-auto">
          {/* Safety Banner */}
          <div className="flex items-start gap-2.5 bg-muted/40 rounded-2xl p-3.5 mb-6">
            <Shield className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              Never send money outside of GlobeTrotter. Report suspicious
              messages to keep our community safe.
            </p>
          </div>

          {/* Listing Context */}
          <ListingContext listing={conversation.listing} />

          {/* Messages */}
          {messages.map((msg, i) => {
            const prevMsg = i > 0 ? messages[i - 1] : null;
            const showDate = shouldShowDateSeparator(
              msg.timestamp,
              prevMsg?.timestamp ?? null
            );

            return (
              <div key={msg.id}>
                {showDate && <DateSeparator date={msg.timestamp} />}
                <div className="py-[3px]">
                  <MessageBubble
                    msg={msg}
                    prevMsg={prevMsg}
                    hostAvatar={conversation.host.avatar}
                    hostName={conversation.host.name}
                  />
                </div>
              </div>
            );
          })}

          {/* Typing */}
          <AnimatePresence>
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 4 }}
                className="flex items-start gap-2 max-w-[88%] sm:max-w-[72%] mr-auto py-1"
              >
                <ChatAvatar
                  src={conversation.host.avatar}
                  name={conversation.host.name}
                  size={28}
                />
                <div className="bg-muted rounded-[18px] rounded-tl-[4px] px-4 py-3 shadow-sm min-w-[60px]">
                  <TypingIndicator />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Input Area */}
      <div className="shrink-0 z-30 bg-background border-t border-border">
        <div className="max-w-3xl mx-auto px-3 py-3">
          <div className="flex items-end gap-1.5">
            <button className="w-10 h-10 rounded-full hover:bg-muted flex items-center justify-center transition-colors shrink-0 mb-0.5">
              <Paperclip className="w-5 h-5 text-muted-foreground" />
            </button>

            <div className="flex-1 relative">
              <textarea
                ref={inputRef}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                onInput={handleInput}
                placeholder="Message..."
                rows={1}
                className="w-full bg-muted rounded-[20px] px-4 py-3 pr-11 text-[15px] outline-none resize-none max-h-32 scrollbar-hide placeholder:text-muted-foreground focus:ring-2 focus:ring-foreground/10 transition-all"
                style={{ minHeight: "46px" }}
              />
              <button className="absolute right-3 bottom-2.5 w-6 h-6 flex items-center justify-center hover:scale-110 transition-transform">
                <Smile className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>

            <AnimatePresence mode="wait">
              {inputText.trim() ? (
                <motion.button
                  key="send"
                  initial={{ scale: 0.7, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.7, opacity: 0 }}
                  transition={{ duration: 0.15 }}
                  onClick={handleSend}
                  className="w-10 h-10 rounded-full bg-foreground text-background flex items-center justify-center hover:scale-105 active:scale-95 transition-all shrink-0 mb-0.5 shadow-md"
                >
                  <Send className="w-4 h-4 ml-0.5" />
                </motion.button>
              ) : (
                <motion.div
                  key="media"
                  initial={{ scale: 0.7, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.7, opacity: 0 }}
                  transition={{ duration: 0.15 }}
                  className="flex items-end gap-0.5 shrink-0"
                >
                  <button className="w-10 h-10 rounded-full hover:bg-muted flex items-center justify-center transition-colors mb-0.5">
                    <Camera className="w-5 h-5 text-muted-foreground" />
                  </button>
                  <button className="w-10 h-10 rounded-full hover:bg-muted flex items-center justify-center transition-colors mb-0.5">
                    <Mic className="w-5 h-5 text-muted-foreground" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}