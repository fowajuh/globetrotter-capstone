import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Map as MapIcon,
  List,
  Star,
  Heart,
  ChevronLeft,
  ChevronRight,
  Globe,
  Home as HomeIcon,
  SlidersHorizontal,
  X,
  Tag,
  SearchX,
  Waves,
  Mountain,
  Sun,
  CloudSun,
  Building2,
  Trees,
  MapPinned,
  Sparkles,
  ShieldCheck,
} from "lucide-react";
import useEmblaCarousel from "embla-carousel-react";
import { ExploreMap } from "@/components/map/ExploreMap";
import { listings, categories } from "@/lib/cameroon-data";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useTravel } from "@/lib/travel-store";

export const Route = createFileRoute("/")({
  component: ExploreScreen,
});

/* ─────────────── Region Config ─────────────── */
const REGION_CONFIG = [
  { name: "Littoral", icon: Waves, gradient: "from-blue-500/20 to-cyan-400/10", color: "text-blue-600" },
  { name: "South", icon: Sun, gradient: "from-amber-500/20 to-yellow-400/10", color: "text-amber-600" },
  { name: "North West", icon: Mountain, gradient: "from-slate-500/20 to-gray-400/10", color: "text-slate-600" },
  { name: "West", icon: CloudSun, gradient: "from-emerald-500/20 to-teal-400/10", color: "text-emerald-600" },
  { name: "Centre", icon: Building2, gradient: "from-violet-500/20 to-purple-400/10", color: "text-violet-600" },
  { name: "Adamawa", icon: Trees, gradient: "from-green-500/20 to-lime-400/10", color: "text-green-600" },
];

/* ─────────────── Category Bar ─────────────── */
function Categories({
  activeId,
  onSelect,
  onOpenFilters,
}: {
  activeId: string | null;
  onSelect: (id: string | null) => void;
  onOpenFilters: () => void;
}) {
  const getIcon = (id: string) => {
    if (id.includes("nature") || id.includes("beach"))
      return <Waves className="w-[22px] h-[22px] stroke-[1.5]" />;
    if (id.includes("culture") || id.includes("city"))
      return <MapPinned className="w-[22px] h-[22px] stroke-[1.5]" />;
    return <HomeIcon className="w-[22px] h-[22px] stroke-[1.5]" />;
  };

  return (
    <div className="sticky top-[68px] md:top-20 z-40 bg-background border-b border-border/60">
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6">
        <div className="flex items-center gap-2 py-4">
          <div className="flex gap-2 overflow-x-auto scrollbar-hide flex-1 items-center pb-1">
            <button
              onClick={() => onSelect(null)}
              className={cn(
                "flex flex-col items-center gap-1.5 px-3 pb-2 transition-all duration-200 border-b-2 shrink-0 min-w-[64px]",
                activeId === null
                  ? "border-foreground text-foreground opacity-100"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:opacity-80 opacity-70"
              )}
            >
              <Globe className="w-[22px] h-[22px] stroke-[1.5]" />
              <span className="text-xs font-semibold whitespace-nowrap">All</span>
            </button>

            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => onSelect(activeId === cat.id ? null : cat.id)}
                className={cn(
                  "flex flex-col items-center gap-1.5 px-3 pb-2 transition-all duration-200 border-b-2 shrink-0 min-w-[64px]",
                  activeId === cat.id
                    ? "border-foreground text-foreground opacity-100"
                    : "border-transparent text-muted-foreground hover:text-foreground hover:opacity-80 opacity-70"
                )}
              >
                {getIcon(cat.id)}
                <span className="text-xs font-semibold whitespace-nowrap">
                  {cat.label}
                </span>
              </button>
            ))}
          </div>

          <div className="pl-2 border-l border-border/60">
            <button
              onClick={onOpenFilters}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border bg-background hover:border-foreground hover:shadow-sm transition-all duration-200 shrink-0"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span className="text-sm font-medium hidden lg:inline">Filters</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─────────────── Listing Card ─────────────── */
function ListingCard({
  listing,
  onHover,
  variant = "default",
}: {
  listing: (typeof listings)[0];
  onHover: (id: string | null) => void;
  variant?: "default" | "compact";
}) {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true });
  const [currentSlide, setCurrentSlide] = useState(0);
  const { wishlist, toggleWish } = useTravel();
  const isWished = wishlist.includes(listing.id);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setCurrentSlide(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    emblaApi.on("select", onSelect);
    return () => {
      emblaApi.off("select", onSelect);
    };
  }, [emblaApi, onSelect]);

  const scrollPrev = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (emblaApi) emblaApi.scrollPrev();
  };

  const scrollNext = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (emblaApi) emblaApi.scrollNext();
  };

  const handleWish = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWish(listing.id);
  };

  if (variant === "compact") {
    return (
      <Link
        to={`/stays/$stayId`}
        params={{ stayId: listing.id }}
        className="block w-full"
      >
        <motion.div
          className="group flex gap-3 cursor-pointer bg-background rounded-2xl border border-border p-3 hover:shadow-lg hover:border-foreground/10 transition-all duration-300"
          onHoverStart={() => onHover(listing.id)}
          onHoverEnd={() => onHover(null)}
        >
          <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-xl overflow-hidden shrink-0 bg-muted">
            <img
              src={listing.images[0]}
              alt={listing.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
          </div>
          <div className="flex-1 min-w-0 py-0.5">
            <div className="flex justify-between items-start gap-2">
              <h3 className="font-semibold text-sm truncate">
                {listing.city}, {listing.region}
              </h3>
              <div className="flex items-center gap-0.5 text-xs shrink-0">
                <Star className="w-3 h-3 fill-foreground" />
                <span>{listing.rating.toFixed(2)}</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground truncate mt-1">
              {listing.title}
            </p>
            <div className="mt-auto pt-2">
              <p className="text-sm">
                <span className="font-semibold">${listing.usd}</span>{" "}
                <span className="text-muted-foreground font-normal">night</span>
              </p>
            </div>
          </div>
        </motion.div>
      </Link>
    );
  }

  return (
    <Link
      to={`/stays/$stayId`}
      params={{ stayId: listing.id }}
      className="block w-full min-w-0"
    >
      <motion.div
        className="group flex flex-col gap-2.5 cursor-pointer"
        onHoverStart={() => onHover(listing.id)}
        onHoverEnd={() => onHover(null)}
      >
        {/* Image Container - Fixed aspect ratio bug with explicit constraints */}
        <div className="relative w-full aspect-[20/19] overflow-hidden rounded-xl bg-muted">
          <div className="overflow-hidden h-full w-full" ref={emblaRef}>
            <div className="flex h-full w-full">
              {listing.images.map((img, idx) => (
                <div
                  className="relative flex-[0_0_100%] h-full w-full min-w-0"
                  key={idx}
                >
                  <img
                    src={img}
                    alt={`${listing.title} - ${idx + 1}`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                    loading="lazy"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Wishlist Button */}
          <button
            onClick={handleWish}
            className="absolute top-3 right-3 z-20 p-1.5 rounded-full hover:scale-110 transition-transform duration-200"
          >
            <Heart
              className={cn(
                "w-6 h-6 drop-shadow-md transition-colors duration-200",
                isWished
                  ? "fill-rose-500 text-rose-500"
                  : "text-white fill-black/20 stroke-[2.5]"
              )}
            />
          </button>

          {/* Carousel Arrows */}
          <button
            onClick={scrollPrev}
            className="absolute left-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/90 backdrop-blur-sm border border-white/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200 z-10 hover:scale-105 shadow-lg"
          >
            <ChevronLeft className="w-4 h-4 text-foreground" />
          </button>
          <button
            onClick={scrollNext}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/90 backdrop-blur-sm border border-white/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200 z-10 hover:scale-105 shadow-lg"
          >
            <ChevronRight className="w-4 h-4 text-foreground" />
          </button>

          {/* Slide Dots */}
          {listing.images.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
              {listing.images.map((_, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "h-1.5 rounded-full transition-all duration-300",
                    currentSlide === idx
                      ? "w-4 bg-white"
                      : "w-1.5 bg-white/60"
                  )}
                />
              ))}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="space-y-0.5">
          <div className="flex justify-between items-start gap-2">
            <h3 className="font-semibold text-[15px] text-foreground leading-tight truncate">
              {listing.city}, {listing.region}
            </h3>
            <div className="flex items-center gap-1 text-sm shrink-0 mt-0.5">
              <Star className="w-3.5 h-3.5 fill-foreground" />
              <span className="font-medium">{listing.rating.toFixed(2)}</span>
            </div>
          </div>
          <p className="text-muted-foreground text-sm truncate leading-snug">
            {listing.tagline}
          </p>
          <p className="pt-1 text-[15px] text-foreground">
            <span className="font-semibold">${listing.usd}</span>{" "}
            <span className="font-normal text-muted-foreground">night</span>
          </p>
        </div>
      </motion.div>
    </Link>
  );
}

/* ─────────────── Section Header ─────────────── */
function SectionHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex justify-between items-end mb-5 gap-4">
      <div className="min-w-0">
        <h2 className="text-[22px] font-bold text-foreground tracking-tight">
          {title}
        </h2>
        {subtitle && (
          <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

/* ─────────────── Main Screen ─────────────── */
function ExploreScreen() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [hoveredListing, setHoveredListing] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"map" | "list">("list");
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const [appliedFilters, setAppliedFilters] = useState({
    minPrice: 0,
    maxPrice: Infinity,
    minBedrooms: 0,
    minBeds: 0,
    minBaths: 0,
  });
  const [draftFilters, setDraftFilters] = useState(appliedFilters);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});

  const toggleSection = (key: string) =>
    setExpandedSections((s) => ({ ...s, [key]: !s[key] }));

  const openFilters = () => {
    setDraftFilters(appliedFilters);
    setIsFiltersOpen(true);
  };

  const applyFilters = () => {
    setAppliedFilters(draftFilters);
    setIsFiltersOpen(false);
  };

  const clearFilters = () => {
    const cleared = {
      minPrice: 0,
      maxPrice: Infinity,
      minBedrooms: 0,
      minBeds: 0,
      minBaths: 0,
    };
    setDraftFilters(cleared);
    setAppliedFilters(cleared);
  };

  useEffect(() => {
    const handleUpdateSearch = (e: Event) => {
      if (e instanceof CustomEvent) {
        setSearchQuery(e.detail);
      }
    };
    window.addEventListener("update-search", handleUpdateSearch);
    return () => window.removeEventListener("update-search", handleUpdateSearch);
  }, []);

  const filteredListings = listings.filter((l) => {
    const matchCat = activeCategory ? l.category === activeCategory : true;
    const q = searchQuery.trim().toLowerCase();
    const matchSearch = q
      ? l.city.toLowerCase().includes(q) ||
        l.region.toLowerCase().includes(q) ||
        l.title.toLowerCase().includes(q)
      : true;
    const matchPrice =
      l.usd >= appliedFilters.minPrice && l.usd <= appliedFilters.maxPrice;
    const matchRooms =
      l.bedrooms >= appliedFilters.minBedrooms &&
      l.beds >= appliedFilters.minBeds &&
      l.baths >= appliedFilters.minBaths;
    return matchCat && matchSearch && matchPrice && matchRooms;
  });

  const draftMatchCount = listings.filter((l) => {
    const matchPrice =
      l.usd >= draftFilters.minPrice && l.usd <= draftFilters.maxPrice;
    const matchRooms =
      l.bedrooms >= draftFilters.minBedrooms &&
      l.beds >= draftFilters.minBeds &&
      l.baths >= draftFilters.minBaths;
    return matchPrice && matchRooms;
  }).length;

  return (
    <div className="min-h-screen flex flex-col bg-background relative">
      <Categories
        activeId={activeCategory}
        onSelect={setActiveCategory}
        onOpenFilters={openFilters}
      />

      {viewMode === "list" ? (
        <main className="flex-1 max-w-screen-2xl mx-auto w-full pb-24">
          {/* Search Results */}
          {searchQuery.trim() ? (
            <section className="px-4 sm:px-6 py-8">
              <div className="mb-8">
                <h2 className="text-2xl font-bold tracking-tight">
                  {filteredListings.length} result
                  {filteredListings.length !== 1 ? "s" : ""} for "{searchQuery}"
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Stays in Cameroon matching your search
                </p>
              </div>
              <div className="grid gap-6 gap-y-10 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                {filteredListings.map((listing) => (
                  <ListingCard
                    key={listing.id}
                    listing={listing}
                    onHover={setHoveredListing}
                  />
                ))}
                {filteredListings.length === 0 && (
                  <div className="col-span-full flex flex-col items-center justify-center py-24 text-center">
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                      <SearchX className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <p className="font-semibold text-lg">No results found</p>
                    <p className="text-muted-foreground text-sm mt-1 max-w-sm">
                      Try adjusting your search or filters to find what you're
                      looking for
                    </p>
                    <button
                      onClick={() => {
                        setSearchQuery("");
                        clearFilters();
                      }}
                      className="mt-4 text-sm font-semibold underline hover:text-primary transition-colors"
                    >
                      Clear all filters
                    </button>
                  </div>
                )}
              </div>
            </section>
          ) : activeCategory ? (
            /* Category Grid */
            <section className="px-4 sm:px-6 py-8">
              <h2 className="text-2xl font-bold tracking-tight mb-6">
                {categories.find((c) => c.id === activeCategory)?.label} ·
                Cameroon
              </h2>
              <div className="grid gap-6 gap-y-10 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                {filteredListings.map((listing) => (
                  <ListingCard
                    key={listing.id}
                    listing={listing}
                    onHover={setHoveredListing}
                  />
                ))}
              </div>
            </section>
          ) : (
            /* Home Feed Sections */
            <div className="space-y-2">
              {/* Section 1: Popular */}
              <section className="px-4 sm:px-6 pt-8 pb-2">
                <SectionHeader
                  title="Popular homes in Cameroon"
                  action={
                    <button
                      onClick={() => toggleSection("popular")}
                      className="text-sm font-semibold underline underline-offset-4 hover:text-primary transition-colors flex items-center gap-1"
                    >
                      {expandedSections.popular ? "Show less" : "Show all"}
                      <ChevronRight
                        className={cn(
                          "w-4 h-4 transition-transform duration-200",
                          expandedSections.popular && "rotate-90"
                        )}
                      />
                    </button>
                  }
                />
                <div
                  className={cn(
                    expandedSections.popular
                      ? "grid gap-6 gap-y-10 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5"
                      : "flex gap-5 overflow-x-auto scrollbar-hide pb-4 -mx-4 px-4 sm:mx-0 sm:px-0 snap-x"
                  )}
                >
                  {(expandedSections.popular
                    ? listings
                    : listings.slice(0, 8)
                  ).map((listing) => (
                    <div
                      key={listing.id}
                      className={cn(
                        expandedSections.popular
                          ? "min-w-0"
                          : "min-w-[280px] sm:min-w-[300px] flex-shrink-0 snap-start"
                      )}
                    >
                      <ListingCard
                        listing={listing}
                        onHover={setHoveredListing}
                      />
                    </div>
                  ))}
                </div>
              </section>

              <div className="h-2 bg-muted/40" />

              {/* Section 2: Hotels */}
              <section className="px-4 sm:px-6 pt-8 pb-2">
                <SectionHeader
                  title="Great hotels for your next trip"
                  subtitle="Plus, get GlobeTrotter credit when you stay at a featured hotel."
                  action={
                    <button
                      onClick={() => toggleSection("hotels")}
                      className="text-sm font-semibold underline underline-offset-4 hover:text-primary transition-colors flex items-center gap-1"
                    >
                      {expandedSections.hotels ? "Show less" : "Show all"}
                      <ChevronRight
                        className={cn(
                          "w-4 h-4 transition-transform duration-200",
                          expandedSections.hotels && "rotate-90"
                        )}
                      />
                    </button>
                  }
                />
                <div
                  className={cn(
                    expandedSections.hotels
                      ? "grid gap-6 gap-y-10 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5"
                      : "flex gap-5 overflow-x-auto scrollbar-hide pb-4 -mx-4 px-4 sm:mx-0 sm:px-0 snap-x"
                  )}
                >
                  {(expandedSections.hotels
                    ? listings.slice(3)
                    : listings.slice(3, 10)
                  ).map((listing) => (
                    <div
                      key={listing.id}
                      className={cn(
                        expandedSections.hotels
                          ? "min-w-0"
                          : "min-w-[280px] sm:min-w-[300px] flex-shrink-0 snap-start"
                      )}
                    >
                      <ListingCard
                        listing={listing}
                        onHover={setHoveredListing}
                      />
                    </div>
                  ))}
                </div>
              </section>

              <div className="h-2 bg-muted/40" />

              {/* Section 3: Regions */}
              <section className="px-4 sm:px-6 pt-8 pb-6">
                <SectionHeader title="Explore by region" />
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                  {REGION_CONFIG.map((region) => {
                    const Icon = region.icon;
                    return (
                      <button
                        key={region.name}
                        onClick={() =>
                          window.dispatchEvent(
                            new CustomEvent("update-search", {
                              detail: region.name,
                            })
                          )
                        }
                        className="flex flex-col items-center gap-3 p-4 rounded-2xl border border-border hover:border-foreground/20 hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 group bg-background"
                      >
                        <div
                          className={cn(
                            "w-14 h-14 rounded-full bg-gradient-to-br flex items-center justify-center transition-transform duration-300 group-hover:scale-110",
                            region.gradient
                          )}
                        >
                          <Icon
                            className={cn("w-7 h-7", region.color)}
                            strokeWidth={1.5}
                          />
                        </div>
                        <span className="text-sm font-semibold text-center group-hover:text-foreground transition-colors">
                          {region.name}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </section>

              <div className="h-2 bg-muted/40" />

              {/* Section 4: Unique Stays */}
              <section className="px-4 sm:px-6 pt-8 pb-10">
                <SectionHeader
                  title="Unique stays"
                  subtitle="One-of-a-kind spaces that are more than just a place to sleep."
                />
                <div className="grid gap-6 gap-y-10 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
                  {listings.slice(5).map((listing) => (
                    <ListingCard
                      key={listing.id}
                      listing={listing}
                      onHover={setHoveredListing}
                    />
                  ))}
                </div>
              </section>
            </div>
          )}

          {/* Floating Pills */}
          <div className="fixed bottom-[80px] left-1/2 -translate-x-1/2 md:bottom-8 z-30 pointer-events-none">
            <div className="bg-foreground text-background px-5 py-3 rounded-full flex items-center gap-2.5 shadow-xl text-sm font-semibold pointer-events-auto">
              <Tag className="w-4 h-4" />
              Prices include all fees
            </div>
          </div>

          <div className="fixed bottom-[80px] right-4 md:bottom-8 md:right-8 z-40">
            <button
              onClick={() => setViewMode("map")}
              className="bg-foreground text-background px-5 py-3 rounded-full flex items-center gap-2 font-semibold shadow-xl hover:scale-105 active:scale-95 transition-all duration-200 text-sm"
            >
              Show map
              <MapIcon className="w-4 h-4" />
            </button>
          </div>
        </main>
      ) : (
        /* Map Mode */
        <div className="flex-1 relative flex flex-col">
          {/* Map Filter Bar */}
          <div className="sticky top-[60px] z-30 bg-background/95 backdrop-blur-md border-b border-border px-4 py-2.5">
            <div className="flex gap-2 overflow-x-auto scrollbar-hide items-center">
              <button
                onClick={() => setViewMode("list")}
                className="shrink-0 flex items-center gap-2 px-4 py-2 rounded-full bg-foreground text-background text-sm font-semibold hover:scale-105 active:scale-95 transition-all duration-200"
              >
                <List className="w-4 h-4" /> Show list
              </button>
              {["Self check-in", "Instant Book", "Free parking", "Pool", "Wifi", "Kitchen"].map(
                (f) => (
                  <button
                    key={f}
                    className="shrink-0 bg-background rounded-full px-4 py-2 text-sm font-medium shadow-sm whitespace-nowrap border border-border hover:border-foreground/30 hover:shadow-md transition-all duration-200"
                  >
                    {f}
                  </button>
                )
              )}
            </div>
          </div>

          {/* Map */}
          <div className="flex-1 w-full min-h-0">
            <ExploreMap
              listings={filteredListings}
              activeId={hoveredListing}
            />
          </div>

          {/* Bottom Sheet */}
          <div className="fixed bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-background via-background/95 to-transparent pt-8 pb-0">
            <div className="flex justify-center mb-3">
              <div className="bg-background/95 backdrop-blur-sm text-foreground px-4 py-2 rounded-full flex items-center gap-2 shadow-lg text-sm font-semibold border border-border">
                <Tag className="w-4 h-4" />
                Prices include all fees
              </div>
            </div>
            <div className="overflow-x-auto scrollbar-hide flex gap-4 px-4 pb-[88px] snap-x">
              {filteredListings.map((listing) => (
                <div
                  key={listing.id}
                  className="min-w-[320px] snap-center"
                >
                  <ListingCard
                    listing={listing}
                    onHover={setHoveredListing}
                    variant="compact"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Filters Modal */}
      <AnimatePresence>
        {isFiltersOpen && (
          <div className="fixed inset-0 z-[100] bg-background md:bg-background/60 md:backdrop-blur-sm flex items-end md:items-center justify-center">
            <motion.div
              initial={{ opacity: 0, y: "100%" }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="bg-background w-full md:w-[780px] h-full md:h-[85vh] md:rounded-3xl shadow-2xl overflow-hidden flex flex-col"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-border">
                <button
                  onClick={() => setIsFiltersOpen(false)}
                  className="w-8 h-8 rounded-full hover:bg-muted flex items-center justify-center transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <h2 className="font-bold text-lg">Filters</h2>
                <div className="w-8" />
              </div>

              {/* Body */}
              <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-10">
                {/* Price */}
                <div>
                  <h3 className="text-[22px] font-bold tracking-tight mb-1">
                    Price range
                  </h3>
                  <p className="text-muted-foreground text-sm mb-6">
                    Nightly price, in USD
                  </p>
                  <div className="flex items-center gap-4">
                    <div className="flex-1 border border-border rounded-xl p-3.5 hover:border-foreground/30 transition-colors">
                      <div className="text-xs text-muted-foreground mb-0.5">
                        Minimum
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-lg">$</span>
                        <input
                          type="number"
                          min={0}
                          value={draftFilters.minPrice}
                          onChange={(e) =>
                            setDraftFilters((f) => ({
                              ...f,
                              minPrice: Math.max(
                                0,
                                Number(e.target.value) || 0
                              ),
                            }))
                          }
                          className="w-full bg-transparent outline-none font-medium text-lg"
                        />
                      </div>
                    </div>
                    <div className="w-6 h-px bg-border shrink-0" />
                    <div className="flex-1 border border-border rounded-xl p-3.5 hover:border-foreground/30 transition-colors">
                      <div className="text-xs text-muted-foreground mb-0.5">
                        Maximum
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-lg">$</span>
                        <input
                          type="number"
                          min={0}
                          placeholder="Any"
                          value={
                            draftFilters.maxPrice === Infinity
                              ? ""
                              : draftFilters.maxPrice
                          }
                          onChange={(e) =>
                            setDraftFilters((f) => ({
                              ...f,
                              maxPrice:
                                e.target.value === ""
                                  ? Infinity
                                  : Math.max(
                                      0,
                                      Number(e.target.value) || 0
                                    ),
                            }))
                          }
                          className="w-full bg-transparent outline-none font-medium text-lg"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="h-px bg-border w-full" />

                {/* Rooms */}
                <div>
                  <h3 className="text-[22px] font-bold tracking-tight mb-6">
                    Rooms and beds
                  </h3>
                  <div className="space-y-5">
                    {(
                      [
                        { key: "minBedrooms", label: "Bedrooms" },
                        { key: "minBeds", label: "Beds" },
                        { key: "minBaths", label: "Bathrooms" },
                      ] as const
                    ).map(({ key, label }) => (
                      <div
                        key={key}
                        className="flex items-center justify-between"
                      >
                        <span className="font-medium text-[15px]">{label}</span>
                        <div className="flex items-center gap-5">
                          <button
                            type="button"
                            onClick={() =>
                              setDraftFilters((f) => ({
                                ...f,
                                [key]: Math.max(0, f[key] - 1),
                              }))
                            }
                            disabled={draftFilters[key] === 0}
                            className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:border-foreground hover:text-foreground transition-all duration-200 disabled:opacity-30 disabled:hover:border-border disabled:hover:text-muted-foreground"
                          >
                            <span className="text-lg leading-none">−</span>
                          </button>
                          <span className="w-10 text-center font-medium text-[15px]">
                            {draftFilters[key] === 0
                              ? "Any"
                              : `${draftFilters[key]}+`}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              setDraftFilters((f) => ({
                                ...f,
                                [key]: Math.min(8, f[key] + 1),
                              }))
                            }
                            className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:border-foreground hover:text-foreground transition-all duration-200"
                          >
                            <span className="text-lg leading-none">+</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="h-px bg-border w-full" />

                {/* Amenities teaser */}
                <div>
                  <h3 className="text-[22px] font-bold tracking-tight mb-4">
                    Amenities
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { icon: Wifi, label: "Wifi" },
                      { icon: ShieldCheck, label: "Self check-in" },
                      { icon: Sparkles, label: "Instant Book" },
                      { icon: MapIcon, label: "Free parking" },
                    ].map(({ icon: Icon, label }) => (
                      <button
                        key={label}
                        className="flex items-center gap-3 p-4 rounded-xl border border-border hover:border-foreground/30 hover:bg-muted/30 transition-all duration-200 text-left"
                      >
                        <Icon className="w-5 h-5 text-muted-foreground" />
                        <span className="font-medium text-sm">{label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 sm:p-6 border-t border-border flex items-center justify-between bg-background">
                <button
                  onClick={clearFilters}
                  className="font-semibold underline underline-offset-4 hover:text-primary transition-colors"
                >
                  Clear all
                </button>
                <Button
                  onClick={applyFilters}
                  className="px-8 py-6 rounded-xl font-semibold text-base shadow-lg hover:shadow-xl transition-shadow"
                >
                  Show {draftMatchCount} place
                  {draftMatchCount !== 1 ? "s" : ""}
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}