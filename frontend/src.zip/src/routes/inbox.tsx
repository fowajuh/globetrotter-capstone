import { createFileRoute, Link } from "@tanstack/react-router";
import { useUser } from "@clerk/clerk-react";
import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import {
  Search,
  CheckCheck,
  Check,
  MoreHorizontal,
  MessageSquarePlus,
  Inbox,
  Pin,
  Archive,
  Trash2,
} from "lucide-react";
import { listings } from "@/lib/cameroon-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/inbox")({
  component: InboxScreen,
});

/* ─────────────── Mock Data ─────────────── */
const mockChats = [
  {
    id: "chat-1",
    hostName: "Amadou",
    listingTitle: listings[0]?.title ?? "Kribi Beach Villa",
    listingImg: listings[0]?.images?.[0] ?? "",
    lastMessage: "Yes, the wifi is very fast and reliable throughout the villa!",
    timestamp: new Date(Date.now() - 1000 * 60 * 50).toISOString(),
    unread: 2,
    isOnline: true,
    pinned: true,
    status: "read" as const,
  },
  {
    id: "chat-2",
    hostName: "Marie",
    listingTitle: listings[1]?.title ?? "Mount Cameroon Lodge",
    listingImg: listings[1]?.images?.[0] ?? "",
    lastMessage: "Looking forward to hosting you next week. The place will be ready by 2pm.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
    unread: 0,
    isOnline: false,
    pinned: false,
    status: "delivered" as const,
  },
  {
    id: "chat-3",
    hostName: "Jean-Pierre",
    listingTitle: listings[2]?.title ?? "Waza Savanna Camp",
    listingImg: listings[2]?.images?.[0] ?? "",
    lastMessage: "Here are the check-in instructions. The key is under the mat.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
    unread: 1,
    isOnline: true,
    pinned: false,
    status: "sent" as const,
  },
  {
    id: "chat-4",
    hostName: "GlobeTrotter Support",
    listingTitle: "Account Verification",
    listingImg: "",
    lastMessage: "Your identity has been successfully verified. Welcome aboard!",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
    unread: 0,
    isOnline: false,
    pinned: false,
    status: "read" as const,
  },
  {
    id: "chat-5",
    hostName: "Fatima",
    listingTitle: listings[3]?.title ?? "Bonanjo Loft",
    listingImg: listings[3]?.images?.[0] ?? "",
    lastMessage: "Can we arrange a late checkout? Our flight is at 8pm.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
    unread: 0,
    isOnline: false,
    pinned: false,
    status: "read" as const,
  },
];

/* ─────────────── Utilities ─────────────── */
function formatTime(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  const mins = Math.floor(diff / 60000);
  const hrs = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (mins < 1) return "Now";
  if (mins < 60) return `${mins}m`;
  if (hrs < 24) return `${hrs}h`;
  if (days < 7) return `${days}d`;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function getInitials(name: string) {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

/* ─────────────── Avatar with Fallback ─────────────── */
function Avatar({
  src,
  name,
  isOnline,
  size = 52,
}: {
  src: string;
  name: string;
  isOnline?: boolean;
  size?: number;
}) {
  const [error, setError] = useState(false);
  const initials = getInitials(name);
  const bgColor =
    initials.charCodeAt(0) % 2 === 0
      ? "bg-rose-100 text-rose-700"
      : "bg-blue-100 text-blue-700";

  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <div
        className={cn(
          "w-full h-full rounded-full overflow-hidden border border-border/60 flex items-center justify-center text-sm font-bold",
          (!src || error) && bgColor
        )}
      >
        {!src || error ? (
          <span>{initials}</span>
        ) : (
          <img
            src={src}
            alt={name}
            className="w-full h-full object-cover"
            onError={() => setError(true)}
            loading="lazy"
          />
        )}
      </div>
      {isOnline && (
        <div
          className="absolute bottom-0.5 right-0.5 bg-emerald-500 border-[2.5px] border-background rounded-full"
          style={{ width: size * 0.27, height: size * 0.27 }}
        />
      )}
    </div>
  );
}

/* ─────────────── Inbox Item ─────────────── */
function InboxItem({
  chat,
  index,
}: {
  chat: (typeof mockChats)[0];
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.035, duration: 0.3 }}
    >
      <Link
        to="/inbox/$chatId"
        params={{ chatId: chat.id }}
        className="group flex items-start gap-3.5 px-4 py-3.5 hover:bg-muted/50 active:bg-muted/80 transition-colors cursor-pointer relative select-none"
      >
        <Avatar src={chat.listingImg} name={chat.hostName} isOnline={chat.isOnline} />

        <div className="flex-1 min-w-0 pt-0.5">
          <div className="flex justify-between items-baseline gap-2 mb-0.5">
            <h3
              className={cn(
                "text-[15px] truncate",
                chat.unread > 0
                  ? "font-bold text-foreground"
                  : "font-semibold text-foreground/90"
              )}
            >
              {chat.hostName}
            </h3>
            <span
              className={cn(
                "text-xs shrink-0 tabular-nums",
                chat.unread > 0
                  ? "font-bold text-primary"
                  : "text-muted-foreground"
              )}
            >
              {formatTime(chat.timestamp)}
            </span>
          </div>

          <div className="flex items-end gap-2 min-w-0">
            <p
              className={cn(
                "text-sm leading-snug truncate flex-1",
                chat.unread > 0
                  ? "font-semibold text-foreground"
                  : "text-muted-foreground"
              )}
            >
              {chat.lastMessage}
            </p>

            <div className="shrink-0 flex items-center gap-1 mb-0.5">
              {chat.unread > 0 ? (
                <span className="min-w-[20px] h-5 px-1.5 bg-primary text-primary-foreground rounded-full text-[11px] font-bold flex items-center justify-center">
                  {chat.unread}
                </span>
              ) : chat.status === "read" ? (
                <CheckCheck className="w-4 h-4 text-primary" />
              ) : chat.status === "delivered" ? (
                <CheckCheck className="w-4 h-4 text-muted-foreground" />
              ) : (
                <Check className="w-4 h-4 text-muted-foreground" />
              )}
            </div>
          </div>

          <p className="text-xs text-muted-foreground mt-0.5 truncate">
            {chat.listingTitle}
          </p>
        </div>

        {/* Hover Actions */}
        <div className="hidden sm:flex absolute right-3 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-background/95 backdrop-blur-sm border border-border rounded-xl shadow-sm items-center overflow-hidden">
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
            className="p-2.5 hover:bg-muted transition-colors"
          >
            <Pin className="w-4 h-4 text-muted-foreground" />
          </button>
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
            className="p-2.5 hover:bg-muted transition-colors border-l border-border"
          >
            <Archive className="w-4 h-4 text-muted-foreground" />
          </button>
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
            className="p-2.5 hover:bg-muted transition-colors border-l border-border"
          >
            <Trash2 className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      </Link>
    </motion.div>
  );
}

/* ─────────────── Main Screen ─────────────── */
function InboxScreen() {
  const { isLoaded, isSignedIn } = useUser();
  const [filter, setFilter] = useState<"all" | "unread">("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredChats = useMemo(() => {
    let chats = [...mockChats];
    if (filter === "unread") chats = chats.filter((c) => c.unread > 0);
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      chats = chats.filter(
        (c) =>
          c.hostName.toLowerCase().includes(q) ||
          c.lastMessage.toLowerCase().includes(q)
      );
    }
    return chats.sort((a, b) => Number(b.pinned) - Number(a.pinned));
  }, [filter, searchQuery]);

  if (!isLoaded) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-muted animate-pulse" />
          <div className="h-3 w-24 bg-muted rounded-full animate-pulse" />
        </div>
      </div>
    );
  }

  if (!isSignedIn) {
    return (
      <div className="flex h-screen items-center justify-center bg-background px-6">
        <div className="text-center max-w-sm">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
            <MessageSquarePlus className="w-7 h-7 text-muted-foreground" />
          </div>
          <h2 className="text-xl font-bold mb-2">Sign in to view messages</h2>
          <p className="text-muted-foreground text-sm mb-6">
            Connect with hosts, get booking confirmations, and manage your trips.
          </p>
          <Link
            to="/login"
            className="inline-flex items-center justify-center px-6 py-3 rounded-xl bg-foreground text-background font-semibold text-sm hover:scale-105 active:scale-95 transition-transform"
          >
            Sign In
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-md border-b border-border">
        <div className="max-w-screen-md mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between py-4">
            <h1 className="text-[28px] font-bold tracking-tight">Messages</h1>
            <button className="w-10 h-10 rounded-full hover:bg-muted flex items-center justify-center transition-colors">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>

          {/* Search */}
          <div className="relative mb-3">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search messages"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-muted rounded-xl pl-10 pr-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-foreground/10 transition-all placeholder:text-muted-foreground"
            />
          </div>

          {/* Filters */}
          <div className="flex gap-2 pb-3 overflow-x-auto scrollbar-hide">
            <button
              onClick={() => setFilter("all")}
              className={cn(
                "px-4 py-1.5 rounded-full text-sm font-semibold transition-all shrink-0",
                filter === "all"
                  ? "bg-foreground text-background shadow-sm"
                  : "border border-border text-foreground hover:border-foreground/40"
              )}
            >
              All
            </button>
            <button
              onClick={() => setFilter("unread")}
              className={cn(
                "px-4 py-1.5 rounded-full text-sm font-semibold transition-all shrink-0",
                filter === "unread"
                  ? "bg-foreground text-background shadow-sm"
                  : "border border-border text-foreground hover:border-foreground/40"
              )}
            >
              Unread
            </button>
            <button className="px-4 py-1.5 rounded-full text-sm font-semibold border border-border text-foreground hover:border-foreground/40 transition-all shrink-0 flex items-center gap-1.5">
              <Archive className="w-3.5 h-3.5" /> Archived
            </button>
          </div>
        </div>
      </div>

      {/* List */}
      <main className="flex-1 max-w-screen-md mx-auto w-full">
        {filteredChats.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 px-6 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Inbox className="w-7 h-7 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-lg mb-1">No messages found</h3>
            <p className="text-muted-foreground text-sm">
              {searchQuery
                ? "Try a different search term"
                : "You're all caught up"}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border/40">
            {filteredChats.map((chat, i) => (
              <InboxItem key={chat.id} chat={chat} index={i} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}