import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { ChevronLeft, Share, Sun, MapPin, Map as MapIcon, Plus, Calendar, Bed, Utensils, Camera, Car, Plane } from "lucide-react";
import { type Trip, type Stop } from "@/lib/mock-data";
import { useTravel } from "@/lib/travel-store";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/trips/$tripId")({
  loader: ({ params }) => {
    const trip = useTravel.getState().myTrips.find((t) => t.id === params.tripId);
    if (!trip) throw notFound();
    return { trip };
  },
  component: TripDetail,
});

const getCategoryIcon = (category: Stop['category']) => {
  switch(category) {
    case 'flight': return <Plane className="w-4 h-4" />;
    case 'stay': return <Bed className="w-4 h-4" />;
    case 'eat': return <Utensils className="w-4 h-4" />;
    case 'see': return <Camera className="w-4 h-4" />;
    case 'move': return <Car className="w-4 h-4" />;
    default: return <MapPin className="w-4 h-4" />;
  }
};
// Use MapPin as fallback for Plane since it's not imported above to avoid clutter. Let's just use MapPin for flight.

function WeatherWidget({ city }: { city: string }) {
  return (
    <div className="bg-gradient-to-br from-blue-500 to-blue-400 rounded-xl p-4 text-white shadow-card relative overflow-hidden">
      <div className="absolute top-0 right-0 p-4 opacity-50">
        <Sun className="w-16 h-16" />
      </div>
      <div className="relative z-10">
        <p className="text-sm font-medium opacity-90">{city}</p>
        <div className="text-4xl font-bold mt-1">28°</div>
        <p className="text-sm mt-1 opacity-90">Sunny • High 31°</p>
      </div>
    </div>
  );
}

function TripDetail() {
  const { trip } = Route.useLoaderData() as { trip: Trip };
  const [activeDay, setActiveDay] = useState(0);

  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Header */}
      <div className="py-4">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2 text-primary hover:opacity-80 transition-opacity">
            <ChevronLeft className="w-5 h-5" />
            <span className="font-semibold hidden sm:inline">Back to trips</span>
          </Link>
          <Button variant="outline" className="gap-2">
            <Share className="w-4 h-4" /> Share trip
          </Button>
        </div>
      </div>

      {/* Hero */}
      <div className="relative h-[40vh] min-h-[300px] w-full bg-muted">
        <img src={trip.cover} alt={trip.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8 max-w-screen-xl mx-auto text-white">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider mb-3">
             {trip.status === 'upcoming' ? 'Upcoming Trip' : trip.status}
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold mb-2">{trip.name}</h1>
          <p className="text-lg opacity-90">{trip.startDate} - {trip.endDate} • {trip.travelers} travelers</p>
        </div>
      </div>

      <main className="max-w-screen-xl mx-auto px-4 sm:px-6 mt-8 flex flex-col lg:flex-row gap-8">
        {/* Left Column: Itinerary Timeline */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Itinerary</h2>
            <Button variant="ghost" className="gap-2 text-primary">
              <MapIcon className="w-4 h-4" /> Map view
            </Button>
          </div>

          {/* Days Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide">
            {trip.days.map((day, idx) => (
              <button
                key={day.index}
                onClick={() => setActiveDay(idx)}
                className={cn(
                  "flex flex-col items-center min-w-[80px] px-4 py-3 rounded-xl border transition-micro",
                  activeDay === idx 
                    ? "bg-primary text-white border-primary shadow-md" 
                    : "bg-card text-foreground border-border hover:border-primary/50"
                )}
              >
                <span className="text-xs font-semibold uppercase opacity-80 mb-1">Day {day.index}</span>
                <span className="text-sm font-bold">{day.date.split(' ')[1]}</span>
              </button>
            ))}
          </div>

          {/* Timeline UI */}
          <div className="mt-8 space-y-8 relative before:absolute before:inset-0 before:ml-[1.4rem] before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-border before:to-transparent">
            {trip.days[activeDay]?.stops.length > 0 ? (
              trip.days[activeDay].stops.map((stop, i) => (
                <motion.div 
                  key={stop.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active"
                >
                  <div className="flex items-center justify-center w-12 h-12 rounded-full border-4 border-background bg-card text-muted-foreground shadow-sm group-[.is-active]:bg-primary group-[.is-active]:text-white group-[.is-active]:shadow-md shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10 transition-micro">
                    {getCategoryIcon(stop.category)}
                  </div>
                  
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-3rem)] p-4 rounded-xl bg-card border border-border shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-primary uppercase">{stop.time}</span>
                      <span className="text-xs font-medium bg-muted px-2 py-1 rounded-md">{stop.duration}</span>
                    </div>
                    <h3 className="font-bold text-lg">{stop.name}</h3>
                    {stop.notes && <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{stop.notes}</p>}
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mt-3 pt-3 border-t border-border">
                      <MapPin className="w-3 h-3" /> {stop.city}
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="text-center py-12 bg-card rounded-xl border border-dashed border-border">
                <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-6 h-6 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-bold mb-2">No plans yet</h3>
                <p className="text-muted-foreground mb-6">Plan your day with our AI itinerary generator.</p>
                <Button>Generate Itinerary</Button>
              </div>
            )}
            
            <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
              <div className="flex items-center justify-center w-12 h-12 rounded-full border-4 border-background bg-muted text-muted-foreground shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10 cursor-pointer hover:bg-primary hover:text-white transition-micro shadow-sm">
                <Plus className="w-6 h-6" />
              </div>
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-3rem)]" />
            </div>
          </div>
        </div>

        {/* Right Column: Widgets & Info */}
        <div className="lg:w-80 shrink-0 space-y-6">
          <WeatherWidget city={trip.destination} />
          
          <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
            <h3 className="font-bold text-lg mb-4">Property Info</h3>
            <div className="aspect-[4/3] rounded-lg overflow-hidden mb-4">
              <img src={trip.cover} alt="Property" className="w-full h-full object-cover" />
            </div>
            <h4 className="font-semibold">{trip.name} Stay</h4>
            <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1">
              <MapPin className="w-3 h-3" /> {trip.destination}
            </p>
            <Button variant="outline" className="w-full mt-4">Contact Host</Button>
          </div>
        </div>
      </main>
    </div>
  );
}
