import { api } from "@/lib/api-client";
import type { Trip as UiTrip } from "@/lib/mock-data";

/** Shape returned by the NestJS API (see backend/prisma/schema.prisma: model Trip). */
export type BackendTrip = {
  id: string;
  ownerId: string;
  name: string;
  subtitle: string | null;
  coverPhotoUrl: string | null;
  originCode: string | null;
  destinationCode: string | null;
  startDate: string;
  endDate: string;
  budgetPlanned: string | number;
  status: "draft" | "upcoming" | "active" | "past";
  createdAt: string;
  updatedAt: string;
};

export type CreateTripInput = {
  name: string;
  subtitle?: string | null;
  coverPhotoUrl?: string | null;
  originCode?: string | null;
  destinationCode?: string | null;
  startDate: string; // ISO datetime
  endDate: string; // ISO datetime
  budgetPlanned?: number;
};

/** Backend has no `days`/spend tracking on Trip yet (that lives on Stops) —
 *  fill in placeholders so existing UI components don't need a rewrite. */
export function backendTripToUiTrip(t: BackendTrip): UiTrip {
  return {
    id: t.id,
    name: t.name,
    subtitle: t.subtitle ?? "",
    code: `GT${t.id.slice(0, 6).toUpperCase()} · ${t.destinationCode ?? "???"}`,
    cover: t.coverPhotoUrl ?? "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1200&q=80",
    origin: t.originCode ?? "—",
    destination: t.destinationCode ?? "—",
    startDate: t.startDate,
    endDate: t.endDate,
    budgetPlanned: Number(t.budgetPlanned),
    budgetSpent: 0, // real value comes from GET /trips/:id/budget-summary
    currency: "USD",
    status: t.status === "active" ? "upcoming" : (t.status as UiTrip["status"]),
    travelers: 1,
    days: [], // real value comes from the trip's stops, fetched separately
  };
}

export const tripsApi = {
  list: (params?: { cursor?: string; limit?: number }) => {
    const qs = new URLSearchParams();
    if (params?.cursor) qs.set("cursor", params.cursor);
    if (params?.limit) qs.set("limit", String(params.limit));
    const suffix = qs.toString() ? `?${qs}` : "";
    return api.get<{ items: BackendTrip[]; nextCursor: string | null }>(`/trips${suffix}`);
  },
  get: (id: string) => api.get<BackendTrip>(`/trips/${id}`),
  create: (input: CreateTripInput) => api.post<BackendTrip>("/trips", input),
  update: (id: string, input: Partial<CreateTripInput> & { status?: BackendTrip["status"] }) =>
    api.patch<BackendTrip>(`/trips/${id}`, input),
  remove: (id: string) => api.delete<void>(`/trips/${id}`),
  duplicate: (id: string) => api.post<BackendTrip>(`/trips/${id}/duplicate`),
  budgetSummary: (id: string) =>
    api.get<{ planned: number; spent: number; remaining: number }>(`/trips/${id}/budget-summary`),
};
